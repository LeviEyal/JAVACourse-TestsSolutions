

public class Node {
	Integer data;
	Node next;
	public Node(Integer data) {
		this.data = data;
		next = null;
	}
	public String toString() {
		return data.toString();
	}
}
