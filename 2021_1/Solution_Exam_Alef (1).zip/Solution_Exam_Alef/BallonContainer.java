

public class BallonContainer {
	int INIT_SIZE = 3;
	Ballon ballons[];
	int size;
	public BallonContainer() {
		ballons = new Ballon[INIT_SIZE];
		size = 0;
	}
	public BallonContainer(BallonContainer bc) {
		if (bc != null) {
			this.size = bc.size;
			this.ballons = new Ballon[bc.ballons.length];
			for (int i = 0; i < this.size; i++) {
				this.ballons[i] = new Ballon(bc.ballons[i]);
			}
		}
	}
	public void add(Ballon b) {
		if (b != null) {
			if (size == ballons.length) resize();
			ballons[size++] = new Ballon(b);
		}
	}
	private void resize() {
		Ballon []t = new Ballon[ballons.length + INIT_SIZE];
		for (int i = 0; i < size; i++) {
			t[i] = ballons[i];
		}
		ballons = t;
	}
	public void removeSmallest(){
		int count = 0;
		for (int i = 0; i < ballons.length; i++) {
			if (ballons[i].getRadius()>1) count++;
		}
		Ballon []t = new Ballon[count];
		int j = 0;
		for (int i = 0; i < ballons.length; i++) {
			if (ballons[i].getRadius()>1) t[j++] = ballons[i];
		}
		ballons = t;
		size = count;
	}
	public int size() {
		return size;
	}
	
}