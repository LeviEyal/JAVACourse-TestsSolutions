

public class Ballon {
	private double x, y, z, r;
	public Ballon(double x, double y, double z, double r) {
		this.x = x;
		this.y = y;
		this.z = z;
		this.r = r;
	}
	public Ballon(Ballon b) {
		this.x = b.x;
		this.y = b.y;
		this.z = b.z;
		this.r = b.r;
	}
	public double volume() {
		return Math.PI*Math.pow(r, 3)*4.0/3.0;
	}
	public boolean isIn(double x, double y, double z) {
		double dist = Math.sqrt((this.x-x)*(this.x-x)+(this.y-y)*(this.y-y)+(this.z-z)*(this.z-z));
		return dist <= this.r;
	}
	public void setRadius(double radius) {
		this.r = radius;
	}
	public double getRadius(){
		return this.r;
	}
}
