

public class MyLinkedList {
	Node head, tail;
	public MyLinkedList() {
		head = tail = null;
	}
	public void add(Integer data) {
		if (head == null) {
			head = new Node(data);
			tail = head;
		}
		else {
			Node n = new Node(data);
			tail.next = n;
			tail = n;
		}
	}
	public String toString() {
		String ans = "[";
		if (head == null) ans = "[]";
		else {
			Node n = head;
			while(n.next != null){
				ans = ans + n.data + ", ";
				n = n.next;
			}
			ans = ans + n.data +"]";
		}
		return ans;
	}

	public void removeMiddle() {
		if (head == null) return;
		if (head.next == null) {
			head = null;
			return;
		}
		int mid = size()/2, i=0;
		Node n=head, prev=head;
		while(i < mid) {
			prev = n;
			n = n.next;
			i++;
		}
		prev.next = n.next;
	}
	public int size() {
		int count = 0;
		Node n = head;
		while (n!=null) {
			n = n.next;
			count++;
		}
		return count;
	}
}
