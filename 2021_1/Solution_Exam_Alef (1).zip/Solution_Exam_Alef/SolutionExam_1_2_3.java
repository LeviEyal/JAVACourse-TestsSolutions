

import java.util.Arrays;

public class SolutionExam_1_2_3 {
	public static boolean isPalindrome(String s) {
		boolean ans = true;
		for(int i=0, j=s.length()-1; ans && i<s.length()/2; i++, j--) {
			if(s.charAt(i) != s.charAt(j)) ans=false;
		}
		return ans;
	}

	public static void sort01(int[]a) {
		int i=0, j = a.length-1;
		while(i < j) {
			if (a[i]==0) i++;
			else if (a[j]==1) j--;
			else if (a[i]==1 && a[j]==0) {
				a[i++] = 0;
				a[j--] = 1;
			}
		}
	}
	public static boolean absoluteSorted(int[][] mat) {
		boolean ans = true;
		for(int i=0; ans &&  i<mat.length; i++) {
			for(int j=1; ans && j<mat[0].length; j++) {
				if (mat[i][j-1] > mat[i][j]) ans = false;
			}
		}
		for(int j=0; ans &&  j<mat[0].length; j++) {
			for(int i=1; ans && i<mat.length; i++) {
				if (mat[i-1][j] > mat[i][j]) ans = false;
			}
		}
		return ans;
	}
	public static boolean absoluteSortedStudent(int[][] mat) {
		for(int i=0; i<mat.length; i++) {
			int prev = mat[i][0];
			for(int j=0; j<mat[i].length; j++) {
				if (mat[i][j] < prev) return false;
				prev = mat[i][j];
			}
		}
		return true;
	}
	public static void checkRemoveMiddle() {
		MyLinkedList list2 = new MyLinkedList();
		list2.add(1);
		System.out.println(list2);
		list2.removeMiddle();
		System.out.println(list2);
		list2.add(1);
		list2.add(2);
		System.out.println(list2);
		list2.removeMiddle();
		System.out.println(list2);
	}
	public static void checIsPalindrom() {
		System.out.println(isPalindrome("a"));
		System.out.println(isPalindrome("aba"));
		System.out.println(isPalindrome("abba"));
		System.out.println(isPalindrome("abca"));		
	}
	public static void checkAbsoluteSorted() {
		int mat1[][] = {{1,2,3},{4,5,6},{7,8,9}};
		System.out.println(absoluteSorted(mat1));
		int mat2[][] = {{1,2,3},{7,8,9},{4,5,6}};
		System.out.println(absoluteSorted(mat2));
		int mat3[][] = {{1,2},{4,3}};
		System.out.println(absoluteSorted(mat3));
	}

	public static void checkSort01() {
		int[]a1 = {0,1,0,1,1,1};
		sort01(a1);
		System.out.println(Arrays.toString(a1));
		int[]a2 = {0,1};
		sort01(a2);
		System.out.println(Arrays.toString(a2));
		int[]a3 = {1,0};
		sort01(a3);
		System.out.println(Arrays.toString(a3));
		int[]a4 = {1,1,1,1,1,0};
		sort01(a4);
		System.out.println(Arrays.toString(a4));
		int[]a5 = {1,1,0,1,1,1};
		sort01(a5);
		System.out.println(Arrays.toString(a5));
	}
	public static void main(String[] args) {
		String s1="A", s2="a";
		System.out.println(s1=s2);
		/////////
		checkRemoveMiddle();
		//////////
		checkSort01();
		//////////
		System.out.println();
		checkAbsoluteSorted();
	}
}
